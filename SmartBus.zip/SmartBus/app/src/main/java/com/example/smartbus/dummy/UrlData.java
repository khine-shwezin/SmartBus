package com.example.smartbus.dummy;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URL;


import javax.net.ssl.HttpsURLConnection;

public class UrlData {
    public UrlData() throws IOException {
        System.out.println("------> UrlData  <-------");
        String st = getData();
    }

    public String getData(){

        HttpURLConnection con = null;
        try {
            String url = "http://datamall2.mytransport.sg//ltaodataservice/BusRoutes?";
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("AccountKey", "jzjEqtM8Tmu/wyOX8jWJuQ==");
            con.setRequestProperty("path", "/ltaodataservice/BusRoutes?");
            con.setRequestProperty("Accept", "application/json");
            con.connect();
            System.out.println(">>>>>>>>>>>>>>>> Connected!");
            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String dataString = br.readLine();
            /*
            String line;
            while ((line = br.readLine()) != null) {

                System.out.println(">>>>>>>>>>>>>> 5.1. line:"+ line);
                sb.append(line + "\n");
            }*/
            br.close();
            System.out.println(">>>>>>>>>>>>>> Result:"+dataString);
            return dataString;
        } catch (MalformedURLException ex) {
            System.out.println("MalForm Error");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("IO Error:"+ex);
            ex.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.disconnect();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return null;
    }
}
